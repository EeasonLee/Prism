
        const withNx = require('./with-nx');
        module.exports = withNx;
        module.exports.withNx = withNx;
        module.exports.composePlugins = require('./compose-plugins').composePlugins;
      